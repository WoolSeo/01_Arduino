#ifndef GY88_h
#define GY88_h

#include "Arduino.h"
#include <Wire.h>
#include <I2Cdev.h>
#include "MPU6050_6Axis_MotionApps20.h"

class GY88
{
  public:

    GY88();
    void initialize();
    void compute();

    #define LED_PIN 6
    float euler[3];
    float ypr[3];
 

  private:

    MPU6050 mpu;
    bool blinkState = false;
    bool dmpReady = false;
    uint8_t mpuIntStatus;
    uint8_t devStatus;  
    uint16_t packetSize;
    uint16_t fifoCount;
    uint8_t fifoBuffer[64];

    Quaternion q;
    VectorInt16 aa;
    VectorInt16 aaReal;
    VectorInt16 aaWorld; 
    VectorFloat gravity; 

    int x = 0;

    volatile bool mpuInterrupt = false;
    static GY88 *pointeur;
    static void ISR();

    void dmpDataReady();
};

#endif
